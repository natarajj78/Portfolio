
Use one detail route per project. Start with a short project title, plain-language summary and metadata for role, period and project context. Show one important artifact before the full story when available.

1. Project overview: What the product does, who it serves and the scope of the work.
2. Business or user problem: What needed to change and the evidence for that problem.
3. My role and responsibilities: Decisions, deliverables and ownership. Distinguish individual work from the team's work.
4. Team and stakeholder context: Disciplines involved, collaborators, constraints and how decisions were agreed.
5. Research and discovery: Questions, participants, methods, observations and what changed because of the findings.
6. Design strategy: Priorities, scope and how the experience supported the product direction.
7. Key UX decisions: Two or three decisions, options considered, tradeoffs and the rationale.
8. Process and methods: The methods actually used, rather than a generic process diagram.
9. Important screens or workflow: Select artifacts that explain behaviour. Add captions describing their purpose.
10. Challenges and constraints: Time, technology, permissions, compliance or organisational constraints that shaped the work.
11. Outcomes and impact: Separate shipped outcomes, evaluation findings and intended benefits. Supply dates and sources for metrics.
12. Key learnings: What changed your view, what you would repeat and what you would do differently.

Use 'Input needed' wherever a fact is missing. Do not invent metrics, release status, participants, team size, client feedback or individual ownership.

