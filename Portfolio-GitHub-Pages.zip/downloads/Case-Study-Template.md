# Case-study structure and filled example


Use one detail route per project. Start with a short project title, plain-language summary and metadata for role, period and project context. Show one important artifact before the full story when available.

1. Project overview: What the product does, who it serves and the scope of the work.
2. Business or user problem: What needed to change and the evidence for that problem.
3. My role and responsibilities: Decisions, deliverables and ownership. Distinguish individual work from the team's work.
4. Team and stakeholder context: Disciplines involved, collaborators, constraints and how decisions were agreed.
5. Research and discovery: Questions, participants, methods, observations and what changed because of the findings.
6. Design strategy: Priorities, scope and how the experience supported the product direction.
7. Key UX decisions: Two or three decisions, options considered, tradeoffs and the rationale.
8. Process and methods: The methods actually used, rather than a generic process diagram.
9. Important screens or workflow: Select artifacts that explain behaviour. Add captions describing their purpose.
10. Challenges and constraints: Time, technology, permissions, compliance or organisational constraints that shaped the work.
11. Outcomes and impact: Separate shipped outcomes, evaluation findings and intended benefits. Supply dates and sources for metrics.
12. Key learnings: What changed your view, what you would repeat and what you would do differently.

Render only sections supported by the project material. Omit dates and role titles when they are not established. Use a design-focus label for exploration work, and distinguish design outputs from post-launch results. The filled GenAI Assist story is the reusable editorial example.


## GenAI Assist: filled example

### Project overview

GenAI Assist explores a better way for consultants to find and use enterprise knowledge. The concept brings guided prompts, conversational search and source references into one experience, with the aim of reducing repetitive research and keeping attention on customer work.

### Business or user problem

Relevant knowledge was spread across repositories. Finding sources and researching opportunities involved repetitive manual search. The design challenge was to make information easier to discover while giving people enough context to assess an AI-generated answer.

### Research and discovery

Discovery observations covered fragmented knowledge access, manual search, prompt customisation, model controls, tagging and answer feedback. Three personas and comparative analysis helped frame different needs. Enterprise security and knowledge curation also shaped the product direction.

### Design strategy

The concept combines guided starting points with open-ended questions. Follow-up prompts support deeper exploration, while source references connect an answer to the knowledge behind it. Metadata, tagging and auditability are part of the enterprise design direction.

### Key UX decisions

Starter prompts make the first interaction more approachable. Conversational follow-ups keep related questions together. Source references help readers inspect the basis of an answer. Feedback and configuration controls address the need to review responses and adapt the experience to different tasks.

### Process and methods

The portfolio follows Discover, Define, Ideate and Design. It includes research observations, comparative analysis, personas, user and task flows, wireframes and detailed interface designs. Together, these show the progression from the knowledge-access problem to a proposed interaction model.

### Important screens or workflow

The workflow moves from a question or starter prompt to an AI response with supporting references, then into follow-up exploration. The research board, flow diagram, wireframes and response design show how those parts connect.

### Challenges and constraints

The work had to consider knowledge curation, an evolving ingestion interface, data loss prevention and role-based access. These requirements connect the visible search experience to the administration and governance behind it.

### Design outcomes

The design outputs establish a proposed enterprise knowledge experience, from discovery themes to detailed response screens. Guided prompts and source references address the intended benefits of easier research and more transparent answers. These are design objectives rather than measured post-launch results.

### Design takeaways

For enterprise AI, answer quality and interaction design belong together. People need a useful starting point, a clear response and a way to inspect its sources. Administration, permissions and feedback deserve attention alongside the conversation itself.