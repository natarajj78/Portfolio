# Nataraj Javvaji portfolio design guide

## Direction

A personal portfolio for senior UX leadership roles. Lead with a clear account of what Nataraj brings to a product team, then use project stories to show how he works. The reference informs the broad progression from leadership to work and career context. All wording, layout, styling and code are original.

Reference access: Search-indexed text was available for Matthew Cunningham's homepage and personal-work page. Direct access was blocked, so exact visual styles, navigation behavior and animation could not be verified. The visual design follows Nataraj's requested large typography, minimalist layouts and professional branding.

## Sitemap

| Route | Purpose |
| --- | --- |
| / | Full leadership portfolio with ten sections |
| /#work | Selected case studies and two project profiles |
| /work/ | All six projects |
| /work/genai-assist/ | Enterprise AI knowledge experience |
| /work/virgin-mobile/ | Commerce, navigation and account care |
| /work/z-gallerie/ | Mobile commerce and checkout specification |
| /work/ebiz-mailer/ | Campaign audience selection and reporting |
| /work/toyota/ | Dealer inventory and pricing project profile |
| /work/ea-help/ | Gamer research and support project profile |
| /design-guide/ | Planning deliverables, wireframes and editable-content guidance |
| /downloads/Nataraj_Javvaji_Resume.docx | Supplied résumé with updated contact email |

## Navigation structure

Primary navigation: Work, About, Leadership, Approach, AI & innovation, Contact.

The first five links lead to homepage sections. Contact ends the story with the current email address. The NJ brand returns to the homepage. A Menu button reveals the same links on mobile. Escape closes the mobile menu and returns focus to its button.

Secondary navigation: All projects, case-study contents, next project, résumé download. Workshops, research and testimonials form part of the homepage's story rather than separate primary-navigation items.

## Information architecture

1. Hero: Name, role, 20+ years of experience, a clear introduction and two actions.
2. Selected work: Six compact project cards: GenAI Assist first, commerce stories next, eBiz Mailer, then Toyota and Electronic Arts. Four case studies and two shorter profiles reflect the material available.
3. About: Career context and the connection between interface engineering and UX practice.
4. Experience & leadership: Recent roles first; earlier experience in an accessible disclosure.
5. Design approach: Understand, find direction, make it tangible, evaluate and refine.
6. AI & innovation: Documented AI-assisted practice, GenAI Assist and a clearly labelled DevOps evidence gap.
7. Workshops & facilitation: Verified credentials and the facilitation approach, with a workshop-story placeholder.
8. Research & insights: Documented research examples, with links to the relevant project stories.
9. Testimonials: A labelled empty state awaiting approved quotes. No invented endorsements.
10. Contact: Senior-role interests, current email, location and résumé download.

Recruiter route: Introduction, selected project, role and responsibilities, decisions, outcomes, contact.
Hiring-manager route: Leadership, career context, approach, project detail, facilitation and research.

## Visual design system

| Token | Value | Use |
| --- | --- | --- |
| Ink | #16171B | Primary text, buttons and brand mark |
| Paper | #F6F7F9 | Main page background |
| White | #FFFFFF | Project and research sections |
| Cobalt | #2449DB | Hero emphasis, focus rings and interaction states |
| Dark | #171923 | Leadership and contact sections |
| Muted | #535661 | Secondary text on light surfaces |
| Line | #D7D9DF | Dividers and grouping |
| Pale blue | #E9EDFB | AI section and project-image framing |
| Light text | #C9CCD7 | Secondary text on dark sections |

The accent serves emphasis and interaction. Project screenshots retain their original colours. Surfaces use almost square corners. Dividers and spacing create hierarchy instead of decorative effects.

### Typography

Implemented stack: Arial, Helvetica, sans-serif. It avoids font-download delays and offers a familiar editorial tone. Optional future type choice: a properly licensed Neue Haas Grotesk or Helvetica Now. A self-hosted Inter family is another practical option after licensing and download verification.

Hero: 48 to 116 px. Section headings: 36 to 62 px. Project headings: 25 to 38 px. Body: 18 px with 1.6 line height. Intro paragraphs: 21 to 28 px. Navigation: 15 px. Labels: 12 px uppercase, reserved for secondary metadata. Regular interface text stays 14 px or larger.

Heading tracking is restrained at about -0.045em. Heading line height is 1.07 and body line height is 1.6. Use sentence case for headings. Avoid em dashes, decorative punctuation, unsupported superlatives and metric claims without evidence.

### Spacing and grids

Spacing rhythm: 8, 16, 24, 32, 40, 56, 80 and 104 px. Use the smaller values inside components and larger values between story sections.

Desktop content: maximum 1440 px including gutters. Gutters grow from 24 to 88 px. The introduction pairs a leadership headline with the supplied, unchanged portrait. Selected work uses compact three-column cards on desktop, two columns on tablets and one column on phones. Narrative sections keep their two-column rhythm.

Buttons: at least 52 px high with a visible focus ring. Links are underlined when used as calls to action. Project cards provide a labelled image link, heading link and clear project link.

### Interaction

Sticky navigation gives readers a consistent route through the homepage. Anchor offsets prevent headings from hiding behind the header. Image hover movement is limited to a small scale change. Reduced-motion preference removes smooth scrolling and transitions. All content remains readable without animation or JavaScript.

## Responsive guidance

Above 1100 px: full navigation, three-column project cards, four approach columns and a case-study contents rail.

From 821 to 1100 px: allow hero actions to wrap, reduce image padding, and use two approach columns.

At 820 px and below: switch to the Menu button, stack narrative columns, put case-study contents above the story and keep controls at least 44 px high.

At 560 px and below: use one project column, stack approach steps and project metadata, allow the hero to wrap naturally and use 24 px page gutters.

Images use intrinsic proportions and object-fit: contain where the screenshot must remain legible. Case-study figures can be opened through normal browser image actions. Email wraps safely without horizontal overflow.

Check at 375, 768 and 1440 px, at 200% text enlargement and with keyboard-only navigation. The static hosting workflow does not provide an interactive local browser preview, so these are implementation targets rather than a claim of completed browser testing.

## Accessibility and performance

Semantic header, nav, main, section, article, figure and footer landmarks. A visible-on-focus skip link. One h1 per page. Descriptive image alt text. Visible focus states. The mobile menu exposes aria-expanded and aria-controls. No colour-only controls. Contrast was calculated for the primary text, muted text, accent and dark-surface combinations.

Project images use supplied WebP assets and lazy loading below the initial viewport. No third-party scripts, trackers, externally hosted fonts or AI service calls. The contact link opens the visitor's email app. The site collects no visitor form data.

## Case-study template

Use one detail route per project. Start with a short project title, plain-language summary and metadata for role, period and project context. Show one important artifact before the full story when available.

1. Project overview: What the product does, who it serves and the scope of the work.
2. Business or user problem: What needed to change and the evidence for that problem.
3. My role and responsibilities: Decisions, deliverables and ownership. Distinguish individual work from the team's work.
4. Team and stakeholder context: Disciplines involved, collaborators, constraints and how decisions were agreed.
5. Research and discovery: Questions, participants, methods, observations and what changed because of the findings.
6. Design strategy: Priorities, scope and how the experience supported the product direction.
7. Key UX decisions: Two or three decisions, options considered, tradeoffs and the rationale.
8. Process and methods: The methods actually used, rather than a generic process diagram.
9. Important screens or workflow: Select artifacts that explain behaviour. Add captions describing their purpose.
10. Challenges and constraints: Time, technology, permissions, compliance or organisational constraints that shaped the work.
11. Outcomes and impact: Separate shipped outcomes, evaluation findings and intended benefits. Supply dates and sources for metrics.
12. Key learnings: What changed your view, what you would repeat and what you would do differently.

Use 'Input needed' wherever a fact is missing. Do not invent metrics, release status, participants, team size, client feedback or individual ownership.

## Content gaps

- Approved testimonials with names, roles, organisations and permission to publish.
- A specific DevOps intelligence project, your contribution and verified results.
- One detailed workshop example with participants, activities and resulting decisions.
- Team size, direct reports, hiring, coaching, budgets and organisation-level leadership outcomes.
- GenAI Assist's individual role, dates, release status and measurable impact.
- eBiz Mailer's role scope, team, research history and delivered outcomes.
- Toyota project artifacts and detailed research, decisions and outcomes.
- LinkedIn profile: https://www.linkedin.com/in/javvaji-nataraj. The supplied portrait is included in the introduction.
- The downloadable source résumé still states 19+ years. This website uses the user's stated 20+ years.

## Content maintenance

Edit portfolio.json for project stories and experience. The website is generated by build.py. Homepage copy is kept in its named sections. make-guide.py generates this guide and full-copy.md. Run python build.py followed by python make-guide.py after changes. All public files are in dist. The project is a static website with reusable page, navigation, footer and case-study render functions.

Deploy dist through Sites, or any static host. A GitHub project-site deployment requires a base-path transformation before publishing. This new version does not replace the existing GitHub portfolio.
