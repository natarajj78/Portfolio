# Full portfolio copy

## index.html

Skip to content NJ Nataraj Javvaji Senior UX Lead Menu Work About Leadership Approach AI & innovation Contact 
Design leadership / India & the United States 20+ years of experience 
I help teams make complex products easier to use. 

I'm Nataraj, a Senior UX Lead. I work with product teams to understand the problem, make thoughtful decisions and turn complex requirements into useful experiences. 
Explore my work Download résumé Nataraj Javvaji / Senior UX Lead 

What I bring to the work 

UX strategy 

I connect user needs with product priorities, using research and design to give teams a clear direction. 

Design leadership 

I work across product, engineering and design to align decisions and carry the experience through delivery. 

Enterprise & AI 

I design for complex workflows, with attention to useful information, clear interaction and trust in AI responses. 

01 / Selected work 
Different problems. Thoughtful decisions. 

Projects across enterprise software, commerce, research and AI. Each story explains the context, the work and the decisions behind it. 

AI & enterprise 
Making knowledge easier to find. 

An enterprise AI experience that brings search, guided prompts and source references into one workflow. 
GenAI Assist View project 
Telecom 
From shopping to account care. 

E-commerce redesign, navigation research and mobile payment flows for Virgin Mobile USA. 
Virgin Mobile USA View project 
Commerce 
A clearer path to purchase. 

Mobile shopping, product detail and checkout specifications for Z Gallerie. 
Z Gallerie View project 
Campaign tools 
From audience selection to campaign insight. 

Wireframes, paper prototypes and reporting interfaces for an email campaign tool. 
eBiz Mailer View project 
Toyota Automobile Project profile Automobile 
Helping dealers work with inventory and pricing. 

Dealer-facing workflows, application flows and interface design for Toyota. 
Toyota View project 
Electronic Arts Digital entertainment Project profile Digital entertainment 
Understanding what players need. 

Interviews and surveys to inform the EA Help support experience. 
Electronic Arts View project Explore all six projects 

02 / About 
A designer's eye. A practical understanding of how products work. 

I've worked across enterprise IT, financial services, commerce, gaming and automotive, in India and the United States. 

My background in interface engineering still shapes how I design. I think about how a flow works, how a team will build it and what people need to get their job done. 

My practice spans research, information architecture, interaction design, prototyping and design systems. I enjoy working with people from different disciplines and making difficult problems easier to discuss. 
Bengaluru / Hyderabad, India Senior UX Lead 

03 / Experience & leadership 
Good design takes a team. 

I bring product, engineering and design into the same conversation, from early discovery to the details of delivery. 
20 + years across design and technology 
Feb 2021 to Present / Bengaluru, India 
Kyndryl / IBM 

Senior UX Lead 

Lead end-to-end product design from discovery through prototypes and high-fidelity interfaces. Align product, engineering and design through human-centred methods. Use generative UI prototyping and AI-assisted usability synthesis. 

Oct 2018 to Feb 2021 / Hyderabad, India 
OSI Digital 

UX Architect / Manager 

Translated ambiguous business requirements into scalable interface frameworks. Planned UX projects from requirements through development-ready design. 

Jun to Sep 2018 / Plano, USA 
Toyota 

UX Architect 

Designed dealer-facing Inventory Management and Pricing Engine experiences. Contributed to product strategy, application flows and mock-ups. 

Mar 2017 to May 2018 / Kansas City, USA 
Virgin Mobile USA 

UX Lead Consultant 

Redesigned the e-commerce website. Used competitive benchmarking of product features and design patterns to inform recommendations. 
Earlier experience 
Jun 2016 to Feb 2017 
J.P. Morgan Chase 

UX Lead Consultant 

Conducted usability testing, heuristic evaluations and benchmarking. Presented research findings and recommendations to product managers, designers and engineers. 

Nov 2015 to May 2016 
Electronic Arts 

UX Consultant 

Interviewed and surveyed gamers to identify needs for the EA Help portal. Applied research to the player-support ecosystem. 

Jul 2012 to Oct 2015 
Z Gallerie 

Senior UX/UI Lead 

Owned UX/UI design and ongoing optimisation of the e-commerce website, supporting the online shopping experience. 

Dec 2009 to Jul 2012 
J.P. Morgan Chase 

Senior User Interface Engineer, Associate 

Built interactive Flex prototypes to demonstrate and validate new product functionality. 

Jul 2007 to Dec 2009 
Prithvi Information Solutions 

Senior Web & UI Designer 

Designed wireframes and interactive prototypes for web and user-interface solutions. 

04 / Design approach 
Start with the problem. Stay close to the evidence. 

There is no single process for every project. I choose methods that help the team learn, decide and move the work forward. 

01 
Understand 

Learn how people work, where they struggle and what the business needs to change. Interviews, contextual inquiry and evaluation help frame the problem. 

02 
Find direction 

Bring findings into a shared view. Use information architecture, flows and workshops to decide what the experience needs to do. 

03 
Make it tangible 

Explore ideas through wireframes and prototypes. Discuss tradeoffs early, then work through the interaction and interface detail. 

04 
Evaluate & refine 

Test the experience, review what people find difficult and use those findings to improve the design. Work with engineering on the details. 

05 / AI & innovation 
AI should help people make better decisions. 

I use AI-assisted research and design tools to explore interfaces and work through usability findings. The value is in what helps the team understand the problem and improve the experience. 

GenAI Assist explores knowledge search, guided prompts and answers with source references. It also surfaces questions about feedback, configuration and enterprise governance. 
Read the GenAI Assist story 
DevOps intelligence 

An area of focus in my practice: making technical signals and operational information easier to understand and act on. 

Input needed: Add a project example, your contribution, the workflows involved and evidence of impact. 

Tools: Figma AI, ChatGPT, Claude and Midjourney. 

06 / Workshops & facilitation 
Make space for the right conversation. 

Workshops help a team work through different views of the same problem and decide what matters next. 

I'm a LUMA Institute Certified Facilitator and Certified Practitioner, and an IBM Enterprise Design Thinking Practitioner. 
Frame the question Bring different perspectives into the room Make decisions visible 
Workshop example to add: The challenge, participants, exercises, decisions reached and what happened next. 

07 / Research & insights 
Listen carefully. Look beyond the screen. 

Interviews, surveys, benchmarking and usability evaluation have shaped my work across products and industries. 

Electronic Arts 
Learn what people need from support. 

Interviews and surveys with gamers informed the EA Help support ecosystem. 
Read the project 
Virgin Mobile USA 
Make navigation visible. 

Competitive benchmarking, card-sorting artifacts and a draft sitemap supported the commerce redesign. 
Read the project 
J.P. Morgan Chase 
Bring findings into product decisions. 

Usability testing, heuristic evaluation and benchmarking informed recommendations to product managers, designers and engineers. 
Research example to document in detail 

08 / Testimonials 
From the people I've worked with. 

Testimonials to be added. 

Input needed: An approved quote, the person's name, role and organisation. No quotes have been supplied yet. 

09 / Contact 
Let's talk about the work ahead. 

I'm exploring Senior UX Lead, UX Manager, Associate Director of UX and UX Director opportunities. 
nataraj.javvaji@gmail.com 
Bengaluru / Hyderabad, India 
Download my résumé 
LinkedIn profile 
Nataraj Javvaji UX strategy. Research. Design leadership. Download résumé Contact © 2026 Nataraj Javvaji

## work/index.html

Skip to content NJ Nataraj Javvaji Senior UX Lead Menu Work About Leadership Approach AI & innovation Contact 
Selected work 
A closer look at the work. 

Six projects across AI, telecom, commerce, automotive and digital entertainment. 

AI & enterprise 
Making knowledge easier to find. 

An enterprise AI experience that brings search, guided prompts and source references into one workflow. 
GenAI Assist View project 
Toyota Automobile Project profile Automobile 
Helping dealers work with inventory and pricing. 

Dealer-facing workflows, application flows and interface design for Toyota. 
Toyota View project 
Telecom 
From shopping to account care. 

E-commerce redesign, navigation research and mobile payment flows for Virgin Mobile USA. 
Virgin Mobile USA View project 
Electronic Arts Digital entertainment Project profile Digital entertainment 
Understanding what players need. 

Interviews and surveys to inform the EA Help support experience. 
Electronic Arts View project 
Commerce 
A clearer path to purchase. 

Mobile shopping, product detail and checkout specifications for Z Gallerie. 
Z Gallerie View project 
Campaign tools 
From audience selection to campaign insight. 

Wireframes, paper prototypes and reporting interfaces for an email campaign tool. 
eBiz Mailer View project Nataraj Javvaji UX strategy. Research. Design leadership. Download résumé Contact © 2026 Nataraj Javvaji

## work/ea-help/index.html

Skip to content NJ Nataraj Javvaji Senior UX Lead Menu Work About Leadership Approach AI & innovation Contact 
All projects 
Digital entertainment / Electronic Arts 

Understanding what players need. 

Interviews and surveys to inform the EA Help support experience. 

Role 

UX Consultant 

Period 

Nov 2015 to May 2016 

Project 

Electronic Arts 
In this story Project overview Business or user problem My role and responsibilities Team and stakeholder context Research and discovery Design strategy Key UX decisions Process and methods Important screens or workflow Challenges and constraints Outcomes and impact Key learnings 
01 
Project overview 

Research for the EA Help portal and player-support ecosystem. 

02 
Business or user problem 

Input needed: Add details for this section. 

03 
My role and responsibilities 

UX Consultant; conducted interviews and surveys with gamers. 

04 
Team and stakeholder context 

Input needed: Add details for this section. 

05 
Research and discovery 

Interviews and surveys identified player needs. Input needed: Participant details and specific findings. 

06 
Design strategy 

Applied research findings to guide the player-support experience. 

07 
Key UX decisions 

Input needed: Add details for this section. 

08 
Process and methods 

Input needed: Add details for this section. 

09 
Important screens or workflow 

Input needed: Add details for this section. 

10 
Challenges and constraints 

Input needed: Add details for this section. 

11 
Outcomes and impact 

Input needed: Add details for this section. 

12 
Key learnings 

Input needed: Add details for this section. 

Source: Résumé: Electronic Arts entry 

Next project 
Z Gallerie 
All projects Nataraj Javvaji UX strategy. Research. Design leadership. Download résumé Contact © 2026 Nataraj Javvaji

## work/ebiz-mailer/index.html

Skip to content NJ Nataraj Javvaji Senior UX Lead Menu Work About Leadership Approach AI & innovation Contact 
All projects 
Campaign tools / eBiz Mailer 

From audience selection to campaign insight. 

Wireframes, paper prototypes and reporting interfaces for an email campaign tool. 

Role 

Design contribution, scope to confirm 

Period 

Project dates to confirm 

Project 

eBiz Mailer 
In this story Project overview Business or user problem My role and responsibilities Team and stakeholder context Research and discovery Design strategy Key UX decisions Process and methods Important screens or workflow Challenges and constraints Outcomes and impact Key learnings 
01 
Project overview 

eBiz Mailer is an email-campaign application with List Manager, Campaign Manager, Survey Manager, Reports and Administration modules visible in the supplied product screens. This case study focuses on profile-based audience-list creation and campaign reporting. The work includes product-context screens, a filtering wireframe, a paper dashboard prototype and an annotated visual design. 
Existing product context 
02 
Business or user problem 

Design framing, inferred from the artifacts: campaign operators need to organise recipient lists, define audience conditions and review campaign performance. The supplied product screens show dense tables and folder navigation; the reports explorations bring delivery, engagement, benchmarks and errors into one view. These are artifact-based interpretations, not findings from a documented user study. 

03 
My role and responsibilities 

My supplied design work covers a profile-list creation wireframe, a paper reports prototype and an annotated reports interface. Together, these artifacts communicate workflow logic, information hierarchy and detailed screen behaviour. Input needed: Confirm my formal role, project dates, ownership of each artifact, implementation involvement and decision-making authority. 

04 
Team and stakeholder context 

The screens provide product context but do not identify the project team, stakeholders or collaboration model. Input needed: Name the organisation or client, product and engineering partners, reviewers and end-user groups; explain who made decisions and how I aligned them. 

05 
Research and discovery 

Artifact review provides the available discovery evidence. The product screens expose module navigation, folder-based list organisation, row selection, list status and dates. The profile wireframe documents data-source selection, attribute conditions and a preview of matching profile data. No interviews, study participants, usability sessions or research findings are supplied. Input needed: Add any research conducted and explain which observations informed the design. 

06 
Design strategy 

The artifacts suggest two complementary directions: make audience-list rules explicit and make campaign reporting easier to scan. The list workflow separates setup from profile conditions and offers a data preview. The reports design pairs a recent-campaign table with grouped performance views and benchmark comparisons. This strategy is interpreted from the supplied designs; intended priorities and rationale need confirmation. 

07 
Key UX decisions 

The annotated profile wireframe specifies operators based on attribute data type: text, number or date. It calls for a date-time picker beside the value field for date-time columns, two condition groups combined with OR, and a preview of profile data. The reports design places creation and report-access actions above a recent-campaign table, groups performance views by metric, and uses contextual department and time filters. These are visible design choices and specifications; their effect on usability has not been measured in the supplied evidence. 
Profile-based list creation 
08 
Process and methods 

The evidence spans product-context review, workflow wireframing, paper prototyping and detailed visual design. The wireframe concentrates on audience-list rules; the paper prototype explores reporting hierarchy; the visual design develops the reporting screen further. These artifacts show different levels of fidelity and two workstreams, rather than a verified single chronological sequence. Input needed: Confirm the order, iteration history, review methods and validation activities. 
Paper exploration of campaign reporting 
09 
Important screens or workflow 

Audience-list flow: create a list and select Profile as the data source; define attribute, operator and value conditions; inspect profile data; then use the available Save action. Reporting flow: enter Reports, review recent campaign publishes, compare performance through delivery, opens, clicks, unsubscribe, benchmark and error panels, and access report actions. The annotated dashboard provides screen-level detail; deeper drill-down destinations are not supplied. 
Reports dashboard design 
10 
Challenges and constraints 

Constraints visible in the artifacts include a dense desktop interface, long list and campaign tables, multiple profile data types, grouped condition logic, and several performance metrics competing for attention. The original screens use legacy browser and application chrome. Input needed: Confirm the actual browser requirements, technical limitations, data volumes, accessibility requirements and delivery constraints; the images alone do not establish them. 

11 
Outcomes and impact 

Documented design outputs: product-context screens, a profile-list creation specification, a paper reports prototype and an annotated reporting dashboard. Intended value, inferred from the designs: clearer audience-rule configuration and a consolidated view of campaign performance. Screenshot counts, percentages and dates are interface data, not evidence of business impact. Input needed: Add shipped status, adoption, usability results, time savings or other measured outcomes. 

12 
Key learnings 

Design takeaway from the artifacts: complex campaign tools benefit from explicit rule semantics and a clear reporting hierarchy. Attribute-aware operators, condition grouping and audience previews make the intended configuration logic visible; grouped metrics and benchmarks support performance interpretation. This is an artifact-based takeaway, not a claim about my retrospective learning. Input needed: Add my reflection on what testing or delivery changed and what I would do differently. 

Source: Supplied eBiz Mailer images: productdesign_ebiz.jpg, wireframe.jpg, paperprototype.jpg and visualdesign_ebiz.jpg 

Next project 
GenAI Assist 
All projects Nataraj Javvaji UX strategy. Research. Design leadership. Download résumé Contact © 2026 Nataraj Javvaji

## work/genai-assist/index.html

Skip to content NJ Nataraj Javvaji Senior UX Lead Menu Work About Leadership Approach AI & innovation Contact 
All projects 
AI & enterprise / GenAI Assist 

Making knowledge easier to find. 

An enterprise AI experience that brings search, guided prompts and source references into one workflow. 

Role 

Role scope to confirm 

Period 

Project dates to confirm 

Project 

GenAI Assist 
In this story Project overview Business or user problem My role and responsibilities Team and stakeholder context Research and discovery Design strategy Key UX decisions Process and methods Important screens or workflow Challenges and constraints Outcomes and impact Key learnings 
01 
Project overview 

An AI-powered knowledge experience intended to help consultants find relevant information, identify opportunities and spend more time on customer work. 

02 
Business or user problem 

Knowledge was fragmented across repositories. Finding sources and researching opportunities required repetitive manual work. 

03 
My role and responsibilities 

Input needed: Confirm your ownership, decisions, deliverables and project dates. The PDF does not attribute individual contributions. 

04 
Team and stakeholder context 

Input needed: Identify the team, stakeholders and how you aligned them. 

05 
Research and discovery 

Documented observations include fragmented knowledge access, manual search overload, demand for model and prompt controls, customisable starter prompts, tagging, metadata, feedback and enterprise security. Artifacts include three personas and comparative analysis. Participant count and study protocol are not supplied. 

06 
Design strategy 

The documented direction combines guided and open-ended interaction, follow-up prompts, semantic search and citation-based summaries. Tagging, metadata and audit logs support discoverability and traceability. These are objectives, rather than verified shipped capabilities. 

07 
Key UX decisions 

The interface artifacts show starter prompts, conversational interaction and source references. Research highlights customisable prompts, answer feedback and model configuration. Input needed: Explain the tradeoffs you made and how evidence shaped each decision. 

08 
Process and methods 

Discover, Define, Ideate and Design, supported by research observations, competitor analysis, personas, user flows, task flows, low-fidelity designs and high-fidelity interfaces. 

09 
Important screens or workflow 

The original flow diagram, wireframes and conversational screens below are excerpts from the supplied Figma portfolio PDF. 
Research and discovery From question to answer Exploring the interface Answers with sources 
10 
Challenges and constraints 

Research records admin-heavy knowledge curation, an ingestion interface in progress, expectations for data loss prevention and role-based access control, and formal UX sign-off to avoid rework. 

11 
Outcomes and impact 

Intended impact: less repetitive research and more time for customer work. Input needed: Release status, adoption, measured time savings, usability results and stakeholder feedback. No delivered metrics are supplied. 

12 
Key learnings 

Input needed: Your reflection on what changed, what you would repeat and what you would do differently. 

Source: GenAI Assist.pdf 

Next project 
Toyota 
All projects Nataraj Javvaji UX strategy. Research. Design leadership. Download résumé Contact © 2026 Nataraj Javvaji

## work/toyota/index.html

Skip to content NJ Nataraj Javvaji Senior UX Lead Menu Work About Leadership Approach AI & innovation Contact 
All projects 
Automobile / Toyota 

Helping dealers work with inventory and pricing. 

Dealer-facing workflows, application flows and interface design for Toyota. 

Role 

UX Architect 

Period 

Jun to Sep 2018 

Project 

Toyota 
In this story Project overview Business or user problem My role and responsibilities Team and stakeholder context Research and discovery Design strategy Key UX decisions Process and methods Important screens or workflow Challenges and constraints Outcomes and impact Key learnings 
01 
Project overview 

Dealer-facing Inventory Management dashboard and Pricing Engine work at Toyota, documented in the résumé. I worked as UX Architect in Plano, USA, from June to September 2018. The reviewed WordPress portfolio does not identify Toyota screens or a Toyota case narrative. 

02 
Business or user problem 

The verified scope is dealer inventory management and pricing. Input needed: Describe the business trigger, dealer tasks, existing workflow problems and success criteria. The product names alone do not establish specific pain points. 

03 
My role and responsibilities 

As UX Architect, I designed a dealer-facing Inventory Management dashboard and Pricing Engine. I contributed to product strategy, application flows and interface mock-ups. Input needed: Add the decisions I owned, leadership contribution and delivery responsibilities. 

04 
Team and stakeholder context 

The résumé identifies Toyota and the role location, but not the team or stakeholders. Input needed: Add dealer representatives, product, engineering and business partners, team size, decision ownership and collaboration context. 

05 
Research and discovery 

Input needed: Add project-specific discovery methods, participants, findings and evidence. General research capabilities elsewhere in my résumé do not establish that those methods were used on this project. 

06 
Design strategy 

The résumé establishes contribution to product strategy and application flows for inventory and pricing. Input needed: Explain the strategy, priorities, tradeoffs and how user or business evidence shaped them. 

07 
Key UX decisions 

Input needed: Add the key inventory and pricing UX decisions, alternatives considered and rationale. No Toyota design artifacts are identified in the supplied WordPress page, so detailed screen behaviour cannot be verified. 

08 
Process and methods 

Documented outputs include application flows and interface mock-ups. Input needed: Add discovery, iteration, design review, prototyping, evaluation and handoff activities specific to Toyota. 

09 
Important screens or workflow 

The verified design areas are the dealer-facing Inventory Management dashboard and Pricing Engine. Input needed: Add approved screens, an annotated dealer task flow and the relationship between inventory and pricing; unrelated archive images have not been assigned to this project. 

10 
Challenges and constraints 

Input needed: Confirm technical dependencies, data constraints, dealer workflows, timeline, accessibility requirements and any commercial or governance restrictions. No project-specific constraints are documented in the available source. 

11 
Outcomes and impact 

Documented contribution: dashboard and Pricing Engine design, product-strategy input, application flows and mock-ups. Input needed: Add release status, stakeholder feedback, adoption, task efficiency or measured business results. No delivered impact metrics are supplied. 

12 
Key learnings 

Input needed: Add my reflection on the dealer domain, decisions that changed through feedback and what I would repeat or improve. A personal retrospective cannot be established from the résumé entry. 

Source: Résumé: Toyota entry. The supplied WordPress portfolio does not identify Toyota project artifacts. 

Next project 
Virgin Mobile USA 
All projects Nataraj Javvaji UX strategy. Research. Design leadership. Download résumé Contact © 2026 Nataraj Javvaji

## work/virgin-mobile/index.html

Skip to content NJ Nataraj Javvaji Senior UX Lead Menu Work About Leadership Approach AI & innovation Contact 
All projects 
Telecom / Virgin Mobile USA 

From shopping to account care. 

E-commerce redesign, navigation research and mobile payment flows for Virgin Mobile USA. 

Role 

UX Lead Consultant 

Period 

Mar 2017 to May 2018 

Project 

Virgin Mobile USA 
In this story Project overview Business or user problem My role and responsibilities Team and stakeholder context Research and discovery Design strategy Key UX decisions Process and methods Important screens or workflow Challenges and constraints Outcomes and impact Key learnings 
01 
Project overview 

Virgin Mobile USA e-commerce redesign and related mobile service designs. The résumé documents the redesign and competitive benchmarking; the WordPress portfolio adds card sorting, a draft site map and payment/AutoPay screen explorations. 

02 
Business or user problem 

Improving website usability and the overall customer experience was the stated redesign aim. The draft sitemap spans shopping, activation, support and account management, showing a broad navigation problem to organise. Specific customer pain points and baseline findings are not supplied. 

03 
My role and responsibilities 

As UX Lead Consultant in Kansas City, USA, I redesigned the e-commerce website and benchmarked competitor product features and design patterns. My portfolio includes navigation and mobile design artifacts. Input needed: Confirm workshop facilitation, individual artifact ownership, leadership scope and implementation responsibilities. 

04 
Team and stakeholder context 

The sitemap distinguishes systems and design/development states, indicating delivery dependencies in the artifact. It does not identify people or team structure. Input needed: Add product, engineering, brand, service and business partners, decision ownership and how I aligned them. 

05 
Research and discovery 

The résumé verifies competitive benchmarking. The WordPress page labels a card-sorting artifact and presents a draft sitemap. The workshop photograph shows mapped screens and annotations, but does not establish participants, protocol or results. Input needed: Add research questions, participants, findings and how they changed the design. 
Card-sorting and navigation artifact 
06 
Design strategy 

The artifacts suggest organising shopping and ongoing service tasks within a connected site architecture. The draft map separates shop, activation, support and account branches; mobile designs make payment and AutoPay states explicit. Confirm the original priorities and the rationale for the structure. 
Draft site architecture 
07 
Key UX decisions 

The sitemap separates purchase, activation, support and account tasks and documents an activation path with authorisation, carrier transfer, payment, account creation and confirmation. Mobile designs distinguish payment status, payment-method editing, AutoPay controls and confirmation states. A shown cancellation variant directs users to call customer care, while another uses in-app confirmation; these are design variants, not proof of final policy. 

08 
Process and methods 

Documented methods and outputs include competitive benchmarking, card sorting, site mapping and visual mockups. The available mobile boards show alternative payment and AutoPay states. Input needed: Add the iteration sequence, testing, review criteria and which variants were selected or shipped. 

09 
Important screens or workflow 

The draft shopping path includes phone selection, product detail/configuration, cart, purchase review and confirmation. A separate activation branch connects authorisation and account setup. The mobile board explores payment summary, AutoPay management, payment-method entry and success/cancellation feedback. These are proposed or documented designs; final release behaviour is unverified. 
Mobile payment and AutoPay explorations 
10 
Challenges and constraints 

Visible challenges include broad site scope, legacy purchase/activation flows, multiple system boundaries and differing account/payment states. The sitemap is explicitly a draft and uses design/development status markers. Input needed: Confirm the technical, service-policy, regulatory, schedule and accessibility constraints that applied. 

11 
Outcomes and impact 

Documented outputs include a redesign contribution, competitive recommendations, navigation artifacts and mobile design explorations. Improving usability was the goal. Input needed: Add shipped scope, task success, conversion, activation completion, support demand or other measured results. Sitemap status colours and sample payment values are not evidence of achieved impact. 

12 
Key learnings 

Artifact-based takeaway: information architecture and explicit interaction states can clarify how shopping connects to activation and ongoing account care. Input needed: Add my retrospective on workshop findings, tested alternatives and delivery tradeoffs. No personal learning or measured improvement is inferred. 

Source: Résumé and https://natarajj.wordpress.com/portfolio/ (project images reviewed) 

Next project 
Electronic Arts 
All projects Nataraj Javvaji UX strategy. Research. Design leadership. Download résumé Contact © 2026 Nataraj Javvaji

## work/z-gallerie/index.html

Skip to content NJ Nataraj Javvaji Senior UX Lead Menu Work About Leadership Approach AI & innovation Contact 
All projects 
Commerce / Z Gallerie 

A clearer path to purchase. 

Mobile shopping, product detail and checkout specifications for Z Gallerie. 

Role 

Senior UX/UI Lead 

Period 

Jul 2012 to Oct 2015 

Project 

Z Gallerie 
In this story Project overview Business or user problem My role and responsibilities Team and stakeholder context Research and discovery Design strategy Key UX decisions Process and methods Important screens or workflow Challenges and constraints Outcomes and impact Key learnings 
01 
Project overview 

Owned UX/UI design and ongoing optimisation of the Z Gallerie e-commerce website. The WordPress archive adds branded mobile navigation, product-detail layouts and an annotated account-and-shipping screen to the résumé evidence. 

02 
Business or user problem 

Design framing, inferred from the screens: shoppers need to find products, understand variations and availability, and supply account and shipping information. Mobile layouts must accommodate product imagery, purchase controls and supporting detail. These are artifact-based interpretations, not documented research findings. 

03 
My role and responsibilities 

As Senior UX/UI Lead in Berkeley, USA, I owned website UX/UI design and ongoing optimisation and developed user-centred shopping solutions. The portfolio includes mobile and specification artifacts. Input needed: Confirm my individual contribution to each screen, team leadership scope and engineering handoff responsibilities. 

04 
Team and stakeholder context 

The source establishes the company and role but does not name collaborators or describe the delivery model. Input needed: Add product, merchandising, engineering and business partners, team size, decision ownership and how I handled stakeholder alignment. 

05 
Research and discovery 

The available evidence is the design archive rather than a research report. Mobile screens expose category navigation, product selection and shopping controls; the specification covers account and shipping inputs. Input needed: Add interviews, analytics, usability findings or other discovery work that informed these designs. 

06 
Design strategy 

The artifacts suggest a strategy of connecting browsing, product evaluation and purchase preparation. Mobile product screens prioritise imagery, price, availability, quantity and Add to Cart, while expandable sections hold supporting information. The account-and-shipping specification makes layout and type treatment explicit. Confirm the original design rationale and priorities. 

07 
Key UX decisions 

Visible decisions include category-based navigation, persistent search, expandable product information, variation selection, stock and delivery messaging, and prominent purchase controls. The desktop specification separates account information from shipping address and annotates typography and spacing. These choices are visible; their usability effect is not measured in the source. 
Account and shipping specification 
08 
Process and methods 

The supplied work includes mobile visual comps and an annotated UI specification. The résumé also records ongoing website optimisation. Input needed: Add wireframes, iteration sequence, review methods, usability validation and implementation checks; do not infer a complete process from finished screens. 

09 
Important screens or workflow 

Mobile flow shown: browse categories or search, inspect a product, review details, select an available variation, enter quantity and use Add to Cart. The desktop artifact shows account and shipping information within a checkout progression. The artifacts illustrate related shopping tasks, not a verified end-to-end release sequence. 
Mobile shopping and product-detail designs 
10 
Challenges and constraints 

Visible design challenges include long product content on small screens, multiple variations, stock and delivery information, and a detailed checkout form. Input needed: Confirm platform limitations, responsive requirements, accessibility expectations, merchandising constraints and delivery deadlines. The source screenshots do not establish those requirements. 

11 
Outcomes and impact 

Documented contribution: ownership of e-commerce UX/UI and ongoing optimisation, plus mobile shopping and specification artifacts in the portfolio. Intended value, inferred from the layouts: clearer product evaluation and purchase preparation. Input needed: Add shipped scope, conversion, abandonment, usability or other verified results. Screen prices and stock labels are not impact metrics. 

12 
Key learnings 

Artifact-based takeaway: product imagery and purchase-critical information need a clear mobile hierarchy, while implementation specifications help communicate detailed design intent. Input needed: Add my personal reflection, validation results and what changed through delivery; this takeaway does not establish a historical learning. 

Source: Résumé and https://natarajj.wordpress.com/portfolio/ (project images reviewed) 

Next project 
eBiz Mailer 
All projects Nataraj Javvaji UX strategy. Research. Design leadership. Download résumé Contact © 2026 Nataraj Javvaji

