# Full portfolio copy

## index.html

Skip to content NJ Nataraj Javvaji Senior UX Lead Menu Work About Leadership Approach AI & innovation Contact 
Design leadership / India & the United States 20+ years of experience 
I help teams make complex products easier to use. 

I'm Nataraj, a Senior UX Lead. I work with product teams to understand the problem, make thoughtful decisions and turn complex requirements into useful experiences. 
Explore my work Download résumé Nataraj Javvaji / Senior UX Lead 

What I bring to the work 

UX strategy 

I connect user needs with product priorities, using research and design to give teams a clear direction. 

Design leadership 

I work across product, engineering and design to align decisions and carry the experience through delivery. 

Enterprise & AI 

I design for complex workflows, with attention to useful information, clear interaction and trust in AI responses. 

01 / Selected work 
Different problems. Thoughtful decisions. 

Projects across enterprise software, commerce, research and AI. Each story explains the context, the work and the decisions behind it. 

AI & enterprise 
Making knowledge easier to find. 

An enterprise AI experience that brings search, guided prompts and source references into one workflow. 
GenAI Assist View project 
Telecom 
From shopping to account care. 

E-commerce redesign, navigation research and mobile payment flows for Virgin Mobile USA. 
Virgin Mobile USA View project 
Commerce 
A clearer path to purchase. 

Mobile shopping, product detail and checkout specifications for Z Gallerie. 
Z Gallerie View project 
Campaign tools 
From audience selection to campaign insight. 

Wireframes, paper prototypes and reporting interfaces for an email campaign tool. 
eBiz Mailer View project 
Toyota Inventory & pricing Automobile 
Helping dealers work with inventory and pricing. 

Dealer-facing workflows, application flows and interface design for Toyota. 
Toyota View project 
Electronic Arts Player support research Digital entertainment 
Understanding what players need. 

Interviews and surveys to inform the EA Help support experience. 
Electronic Arts View project Explore all six projects 

02 / About 
A designer's eye. A practical understanding of how products work. 

I've worked across enterprise IT, financial services, commerce, gaming and automotive, in India and the United States. 

My background in interface engineering still shapes how I design. I think about how a flow works, how a team will build it and what people need to get their job done. 

My practice spans research, information architecture, interaction design, prototyping and design systems. I enjoy working with people from different disciplines and making difficult problems easier to discuss. 
Bengaluru / Hyderabad, India Senior UX Lead 

03 / Experience & leadership 
Good design takes a team. 

I bring product, engineering and design into the same conversation, from early discovery to the details of delivery. 
20 + years across design and technology 
Feb 2021 to Present / Bengaluru, India 
Kyndryl / IBM 

Senior UX Lead 

Lead end-to-end product design from discovery through prototypes and high-fidelity interfaces. Align product, engineering and design through human-centred methods. Use generative UI prototyping and AI-assisted usability synthesis. 

Oct 2018 to Feb 2021 / Hyderabad, India 
OSI Digital 

UX Architect / Manager 

Translated ambiguous business requirements into scalable interface frameworks. Planned UX projects from requirements through development-ready design. 

Jun to Sep 2018 / Plano, USA 
Toyota 

UX Architect 

Designed dealer-facing Inventory Management and Pricing Engine experiences. Contributed to product strategy, application flows and mock-ups. 

Mar 2017 to May 2018 / Kansas City, USA 
Virgin Mobile USA 

UX Lead Consultant 

Redesigned the e-commerce website. Used competitive benchmarking of product features and design patterns to inform recommendations. 
Earlier experience 
Jun 2016 to Feb 2017 
J.P. Morgan Chase 

UX Lead Consultant 

Conducted usability testing, heuristic evaluations and benchmarking. Presented research findings and recommendations to product managers, designers and engineers. 

Nov 2015 to May 2016 
Electronic Arts 

UX Consultant 

Interviewed and surveyed gamers to identify needs for the EA Help portal. Applied research to the player-support ecosystem. 

Jul 2012 to Oct 2015 
Z Gallerie 

Senior UX/UI Lead 

Owned UX/UI design and ongoing optimisation of the e-commerce website, supporting the online shopping experience. 

Dec 2009 to Jul 2012 
J.P. Morgan Chase 

Senior User Interface Engineer, Associate 

Built interactive Flex prototypes to demonstrate and validate new product functionality. 

Jul 2007 to Dec 2009 
Prithvi Information Solutions 

Senior Web & UI Designer 

Designed wireframes and interactive prototypes for web and user-interface solutions. 

04 / Design approach 
Start with the problem. Stay close to the evidence. 

There is no single process for every project. I choose methods that help the team learn, decide and move the work forward. 

01 
Understand 

Learn how people work, where they struggle and what the business needs to change. Interviews, contextual inquiry and evaluation help frame the problem. 

02 
Find direction 

Bring findings into a shared view. Use information architecture, flows and workshops to decide what the experience needs to do. 

03 
Make it tangible 

Explore ideas through wireframes and prototypes. Discuss tradeoffs early, then work through the interaction and interface detail. 

04 
Evaluate & refine 

Test the experience, review what people find difficult and use those findings to improve the design. Work with engineering on the details. 

05 / AI & innovation 
AI should help people make better decisions. 

I use AI-assisted research and design tools to explore interfaces and work through usability findings. The value is in what helps the team understand the problem and improve the experience. 

GenAI Assist explores knowledge search, guided prompts and answers with source references. It also surfaces questions about feedback, configuration and enterprise governance. 
Read the GenAI Assist story 
DevOps intelligence 

An area of focus in my practice: making technical signals and operational information easier to understand and act on. 

My focus is on clear workflows, readable security information and the decisions people need to make across the software delivery lifecycle. 

Tools: Figma AI, ChatGPT, Claude and Midjourney. 

06 / Workshops & facilitation 
Make space for the right conversation. 

Workshops help a team work through different views of the same problem and decide what matters next. 

I'm a LUMA Institute Certified Facilitator and Certified Practitioner, and an IBM Enterprise Design Thinking Practitioner. 
Frame the question Bring different perspectives into the room Make decisions visible 
My facilitation approach starts with a shared question, brings different perspectives into view and turns the discussion into priorities the team can act on. 

07 / Research & insights 
Listen carefully. Look beyond the screen. 

Interviews, surveys, benchmarking and usability evaluation have shaped my work across products and industries. 

Electronic Arts 
Learn what people need from support. 

Interviews and surveys with gamers informed the EA Help support ecosystem. 
Read the project 
Virgin Mobile USA 
Make navigation visible. 

Competitive benchmarking, card-sorting artifacts and a draft sitemap supported the commerce redesign. 
Read the project 
J.P. Morgan Chase 
Bring findings into product decisions. 

Usability testing, heuristic evaluation and benchmarking informed recommendations to product managers, designers and engineers. 
Explore my experience 

08 / Collaboration 
Different perspectives. A shared direction. 

My work connects research, product priorities and the realities of delivery. 

I bring findings and design options into discussions with product managers, designers and engineers. Flows, prototypes and specifications make the choices concrete and help teams review the experience together. 
Explore my leadership experience 

09 / Contact 
Let's talk about the work ahead. 

I'm exploring Senior UX Lead, UX Manager, Associate Director of UX and UX Director opportunities. 
nataraj.javvaji@gmail.com 
Bengaluru / Hyderabad, India 
Download my résumé 
LinkedIn profile 
Nataraj Javvaji UX strategy. Research. Design leadership. Download résumé Contact © 2026 Nataraj Javvaji

## work/index.html

Skip to content NJ Nataraj Javvaji Senior UX Lead Menu Work About Leadership Approach AI & innovation Contact 
Selected work 
A closer look at the work. 

Six projects across AI, telecom, commerce, automotive and digital entertainment. 

AI & enterprise 
Making knowledge easier to find. 

An enterprise AI experience that brings search, guided prompts and source references into one workflow. 
GenAI Assist View project 
Toyota Inventory & pricing Automobile 
Helping dealers work with inventory and pricing. 

Dealer-facing workflows, application flows and interface design for Toyota. 
Toyota View project 
Telecom 
From shopping to account care. 

E-commerce redesign, navigation research and mobile payment flows for Virgin Mobile USA. 
Virgin Mobile USA View project 
Electronic Arts Player support research Digital entertainment 
Understanding what players need. 

Interviews and surveys to inform the EA Help support experience. 
Electronic Arts View project 
Commerce 
A clearer path to purchase. 

Mobile shopping, product detail and checkout specifications for Z Gallerie. 
Z Gallerie View project 
Campaign tools 
From audience selection to campaign insight. 

Wireframes, paper prototypes and reporting interfaces for an email campaign tool. 
eBiz Mailer View project Nataraj Javvaji UX strategy. Research. Design leadership. Download résumé Contact © 2026 Nataraj Javvaji

## work/ea-help/index.html

Skip to content NJ Nataraj Javvaji Senior UX Lead Menu Work About Leadership Approach AI & innovation Contact 
All projects 
Digital entertainment / Electronic Arts 

Understanding what players need. 

Interviews and surveys to inform the EA Help support experience. 

Role 

UX Consultant 

Period 

Nov 2015 to May 2016 

Project 

Electronic Arts 
In this story Project overview My role and responsibilities Research and discovery Design strategy Design contribution 
01 
Project overview 

Research for the EA Help portal and player-support ecosystem at Electronic Arts. I worked as UX Consultant in Austin, USA, from November 2015 to May 2016. 

02 
My role and responsibilities 

I interviewed and surveyed gamers to identify their needs and applied the research to the player-support experience. 

03 
Research and discovery 

Interviews and surveys brought player perspectives into the work. The research focused on understanding needs relevant to the EA Help portal and its wider support ecosystem. 

04 
Design strategy 

Research findings guided the player-support experience, connecting what gamers needed with the design of EA Help. 

05 
Design contribution 

The contribution was research-led input to the EA Help portal and player-support ecosystem through interviews and surveys with gamers. 

Source: Résumé: Electronic Arts entry 

Next project 
Z Gallerie 
All projects Nataraj Javvaji UX strategy. Research. Design leadership. Download résumé Contact © 2026 Nataraj Javvaji

## work/ebiz-mailer/index.html

Skip to content NJ Nataraj Javvaji Senior UX Lead Menu Work About Leadership Approach AI & innovation Contact 
All projects 
Campaign tools / eBiz Mailer 

From audience selection to campaign insight. 

Wireframes, paper prototypes and reporting interfaces for an email campaign tool. 

Design focus 

Audience configuration and campaign reporting 

Project 

eBiz Mailer 
In this story Project overview Business or user problem My role and responsibilities Research and discovery Design strategy Key UX decisions Process and methods Important screens or workflow Challenges and constraints Design outcomes Design takeaways 
01 
Project overview 

eBiz Mailer is an email-campaign application with list, campaign, survey, reporting and administration areas. This work focuses on profile-based audience creation and campaign reporting, using a filtering wireframe, paper dashboard prototype and annotated visual design. 
Existing product context 
02 
Business or user problem 

The product screens show dense lists, folders and campaign tables. The design explores how to make audience conditions explicit and how to bring delivery, engagement, benchmarks and errors into a readable reporting view. 

03 
My role and responsibilities 

The design work in this portfolio covers a profile-list creation wireframe, a paper reports prototype and an annotated reports interface. These artifacts communicate workflow logic, information hierarchy and screen behaviour. 

04 
Research and discovery 

The existing product screens provide the starting context: module navigation, folder-based list organisation, row selection, status and dates. The profile wireframe develops data-source selection, attribute conditions and a preview of matching audience data. 

05 
Design strategy 

Two connected ideas guide the designs: make audience rules understandable before saving a list, and make campaign performance easier to compare. List setup is separated from filter conditions. Reporting combines recent campaigns with grouped metrics and benchmark views. 

06 
Key UX decisions 

Filter operators depend on the attribute type: text, number or date. Date-time values have an adjacent picker. Condition groups can be combined with OR, and a data preview makes the resulting selection visible. The reporting layout groups performance metrics and provides department and time filters. 
Profile-based list creation 
07 
Process and methods 

The work spans product-context review, workflow wireframing, paper prototyping and visual design. The audience wireframe concentrates on rule behaviour, while the paper and detailed reporting designs explore dashboard hierarchy at different levels of fidelity. 
Paper exploration of campaign reporting 
08 
Important screens or workflow 

Audience creation starts with a list and Profile data source, followed by attribute, operator and value conditions. A data preview supports review before saving. Reporting begins with recent campaign publishes, then delivery, opens, clicks, unsubscribes, benchmarks and errors. 
Reports dashboard design 
09 
Challenges and constraints 

The designs address a dense desktop interface, long tables, multiple profile data types, grouped conditions and competing performance metrics. The challenge is to preserve useful detail while giving configuration and reporting a clear structure. 

10 
Design outcomes 

The outputs include product-context screens, a profile-list specification, a paper dashboard prototype and an annotated reporting interface. They demonstrate a design direction for clearer audience configuration and consolidated campaign review. Values shown inside the screens illustrate the interface rather than business results. 

11 
Design takeaways 

Complex campaign tools need clear rules and a readable reporting hierarchy. Type-aware operators, condition grouping and previews make configuration easier to inspect. Grouped metrics and benchmarks give campaign data context. 

Source: Supplied eBiz Mailer images: productdesign_ebiz.jpg, wireframe.jpg, paperprototype.jpg and visualdesign_ebiz.jpg 

Next project 
GenAI Assist 
All projects Nataraj Javvaji UX strategy. Research. Design leadership. Download résumé Contact © 2026 Nataraj Javvaji

## work/genai-assist/index.html

Skip to content NJ Nataraj Javvaji Senior UX Lead Menu Work About Leadership Approach AI & innovation Contact 
All projects 
AI & enterprise / GenAI Assist 

Making knowledge easier to find. 

An enterprise AI experience that brings search, guided prompts and source references into one workflow. 

Design focus 

Enterprise knowledge and conversational UX 

Project 

GenAI Assist 
In this story Project overview Business or user problem Research and discovery Design strategy Key UX decisions Process and methods Important screens or workflow Challenges and constraints Design outcomes Design takeaways 
01 
Project overview 

GenAI Assist explores a better way for consultants to find and use enterprise knowledge. The concept brings guided prompts, conversational search and source references into one experience, with the aim of reducing repetitive research and keeping attention on customer work. 

02 
Business or user problem 

Relevant knowledge was spread across repositories. Finding sources and researching opportunities involved repetitive manual search. The design challenge was to make information easier to discover while giving people enough context to assess an AI-generated answer. 

03 
Research and discovery 

Discovery observations covered fragmented knowledge access, manual search, prompt customisation, model controls, tagging and answer feedback. Three personas and comparative analysis helped frame different needs. Enterprise security and knowledge curation also shaped the product direction. 

04 
Design strategy 

The concept combines guided starting points with open-ended questions. Follow-up prompts support deeper exploration, while source references connect an answer to the knowledge behind it. Metadata, tagging and auditability are part of the enterprise design direction. 

05 
Key UX decisions 

Starter prompts make the first interaction more approachable. Conversational follow-ups keep related questions together. Source references help readers inspect the basis of an answer. Feedback and configuration controls address the need to review responses and adapt the experience to different tasks. 

06 
Process and methods 

The portfolio follows Discover, Define, Ideate and Design. It includes research observations, comparative analysis, personas, user and task flows, wireframes and detailed interface designs. Together, these show the progression from the knowledge-access problem to a proposed interaction model. 

07 
Important screens or workflow 

The workflow moves from a question or starter prompt to an AI response with supporting references, then into follow-up exploration. The research board, flow diagram, wireframes and response design show how those parts connect. 
Research and discovery From question to answer Exploring the interface Answers with sources 
08 
Challenges and constraints 

The work had to consider knowledge curation, an evolving ingestion interface, data loss prevention and role-based access. These requirements connect the visible search experience to the administration and governance behind it. 

09 
Design outcomes 

The design outputs establish a proposed enterprise knowledge experience, from discovery themes to detailed response screens. Guided prompts and source references address the intended benefits of easier research and more transparent answers. These are design objectives rather than measured post-launch results. 

10 
Design takeaways 

For enterprise AI, answer quality and interaction design belong together. People need a useful starting point, a clear response and a way to inspect its sources. Administration, permissions and feedback deserve attention alongside the conversation itself. 

Source: GenAI Assist.pdf 

Next project 
Toyota 
All projects Nataraj Javvaji UX strategy. Research. Design leadership. Download résumé Contact © 2026 Nataraj Javvaji

## work/toyota/index.html

Skip to content NJ Nataraj Javvaji Senior UX Lead Menu Work About Leadership Approach AI & innovation Contact 
All projects 
Automobile / Toyota 

Helping dealers work with inventory and pricing. 

Dealer-facing workflows, application flows and interface design for Toyota. 

Role 

UX Architect 

Period 

Jun to Sep 2018 

Project 

Toyota 
In this story Project overview My role and responsibilities Design strategy Process and methods Design contribution 
01 
Project overview 

Dealer-facing Inventory Management and Pricing Engine design at Toyota. I worked as UX Architect in Plano, USA, from June to September 2018. 

02 
My role and responsibilities 

I designed the Inventory Management dashboard and Pricing Engine experience, contributing to product strategy, application flows and interface mock-ups. 

03 
Design strategy 

The work connected product-strategy input with application flows and interface design across two dealer-facing areas: inventory management and pricing. 

04 
Process and methods 

Application flows described the structure of the experience. Interface mock-ups translated that structure into screen-level design for the inventory dashboard and Pricing Engine. 

05 
Design contribution 

The contribution comprises dealer-facing dashboard and Pricing Engine designs, product-strategy input, application flows and mock-ups. This project profile focuses on that documented design scope. 

Source: Résumé: Toyota entry. 

Next project 
Virgin Mobile USA 
All projects Nataraj Javvaji UX strategy. Research. Design leadership. Download résumé Contact © 2026 Nataraj Javvaji

## work/virgin-mobile/index.html

Skip to content NJ Nataraj Javvaji Senior UX Lead Menu Work About Leadership Approach AI & innovation Contact 
All projects 
Telecom / Virgin Mobile USA 

From shopping to account care. 

E-commerce redesign, navigation research and mobile payment flows for Virgin Mobile USA. 

Role 

UX Lead Consultant 

Period 

Mar 2017 to May 2018 

Project 

Virgin Mobile USA 
In this story Project overview Business or user problem My role and responsibilities Research and discovery Design strategy Key UX decisions Process and methods Important screens or workflow Challenges and constraints Design outcomes Design takeaways 
01 
Project overview 

An e-commerce redesign for Virgin Mobile USA, connecting shopping, activation and ongoing account care. The work includes competitive benchmarking, navigation mapping and mobile payment explorations. 

02 
Business or user problem 

The redesign aimed to improve website usability and the overall customer experience. Shopping, activation, support and account management formed a broad set of tasks to organise within a connected site architecture. 

03 
My role and responsibilities 

As UX Lead Consultant in Kansas City, I redesigned the e-commerce website and benchmarked competitor product features and design patterns. The project material includes navigation artifacts and mobile payment designs. 

04 
Research and discovery 

Competitive benchmarking informed recommendations for the experience. Card-sorting material and a working sitemap made navigation options visible, connecting shopping, activation, support and account tasks. 
Card-sorting and navigation artifact 
05 
Design strategy 

The site architecture separates major customer tasks while showing the links between them. Payment and AutoPay explorations extend that structure into account care, where status, editing and confirmation need clear treatment. 
Draft site architecture 
06 
Key UX decisions 

Shopping, activation, support and account management have distinct branches in the sitemap. The activation flow includes authorisation, carrier transfer, payment and account setup. Mobile designs distinguish payment summary, method editing, AutoPay management and confirmation. Cancellation screens explore both customer-care and in-app paths as design alternatives. 

07 
Process and methods 

Competitive benchmarking, card sorting, site mapping and visual mockups made the redesign tangible. Navigation artifacts show the breadth of the service, while mobile boards explore specific payment and AutoPay states. 

08 
Important screens or workflow 

The shopping path covers phone selection, product detail, cart, purchase review and confirmation. Activation connects authorisation with account setup. The mobile board focuses on payment summary, payment-method entry, AutoPay and success or cancellation feedback. 
Mobile payment and AutoPay explorations 
09 
Challenges and constraints 

The sitemap shows multiple systems and design/development states. The design needed to account for the breadth of shopping and service tasks, as well as differences between purchase, activation and recurring payment interactions. 

10 
Design outcomes 

The work produced redesign contributions, competitive recommendations, navigation artifacts and mobile payment explorations. These outputs show a connected view of commerce and account care, with improving usability as the project goal. 

11 
Design takeaways 

A telecom experience continues after the purchase. Navigation needs to connect shopping with activation, support and payments. Explicit interaction states make those transitions easier to explain and review. 

Source: Résumé and https://natarajj.wordpress.com/portfolio/ 

Next project 
Electronic Arts 
All projects Nataraj Javvaji UX strategy. Research. Design leadership. Download résumé Contact © 2026 Nataraj Javvaji

## work/z-gallerie/index.html

Skip to content NJ Nataraj Javvaji Senior UX Lead Menu Work About Leadership Approach AI & innovation Contact 
All projects 
Commerce / Z Gallerie 

A clearer path to purchase. 

Mobile shopping, product detail and checkout specifications for Z Gallerie. 

Role 

Senior UX/UI Lead 

Period 

Jul 2012 to Oct 2015 

Project 

Z Gallerie 
In this story Project overview Business or user problem My role and responsibilities Design strategy Key UX decisions Process and methods Important screens or workflow Challenges and constraints Design outcomes Design takeaways 
01 
Project overview 

UX/UI design and ongoing optimisation for Z Gallerie’s e-commerce website. The project material includes mobile navigation, product-detail layouts and an annotated account-and-shipping specification. 

02 
Business or user problem 

The screens address a practical shopping challenge: presenting product imagery, variations, price and availability alongside clear purchase controls. On mobile, supporting detail needs room without obscuring the next action. 

03 
My role and responsibilities 

As Senior UX/UI Lead in Berkeley, I owned website UX/UI design and ongoing optimisation, developing user-centred solutions for the online shopping experience. 

04 
Design strategy 

The mobile layouts connect browsing, product evaluation and purchase preparation. Product imagery and purchase information lead the page, with expandable sections for supporting detail. Checkout specifications communicate the layout and type treatment for account and shipping information. 

05 
Key UX decisions 

Category navigation and search support product discovery. Variation selection, stock and delivery messaging sit alongside prominent purchase controls. Expandable information manages longer content. The account-and-shipping specification separates the two information groups and documents spacing and typography. 
Account and shipping specification 
06 
Process and methods 

Mobile visual designs show the shopping experience at screen level. An annotated UI specification captures implementation detail for account and shipping. These artifacts complement the ongoing website optimisation recorded in the role. 

07 
Important screens or workflow 

The mobile sequence shows category browsing or search, product inspection, variation selection, quantity and Add to Cart. The desktop checkout artifact places account and shipping details within a purchase progression. 
Mobile shopping and product-detail designs 
08 
Challenges and constraints 

The layouts address long product content, multiple variations, stock and delivery information, and detailed checkout inputs. The design task is to keep purchase-critical information visible while making supporting content accessible. 

09 
Design outcomes 

The contribution includes e-commerce UX/UI ownership, ongoing optimisation, mobile shopping designs and checkout specifications. The visible layouts focus on product evaluation and purchase preparation; the case study presents those design outputs without claiming a conversion uplift. 

10 
Design takeaways 

Mobile commerce depends on clear priorities. Product imagery draws attention, but variations, availability and purchase actions need equal care. Detailed specifications carry that design intent into implementation conversations. 

Source: Résumé and https://natarajj.wordpress.com/portfolio/ 

Next project 
eBiz Mailer 
All projects Nataraj Javvaji UX strategy. Research. Design leadership. Download résumé Contact © 2026 Nataraj Javvaji

